import React, { Component } from 'react';
import axios from 'axios';
import './App.css';

class AddBook extends Component {
    constructor() {

        super();
        this.state =
        {
            bookid: 0,
            bookName: '',
            authorName: '',
            publishedDate: new Date(),
            price: 999,
            errormsgid: '',
            errormsgprice: ''
        }

    }

    setbookid(event) {
        this.setState({ bookid: event.target.value })
    }

    setbookName(event) {
        this.setState({ bookName: event.target.value })
    }

    setauthorName(event) {
        this.setState({ authorName: event.target.value })
    }

    setpublishedDate(event) {
        this.setState({ publishedDate: event.target.value })
    }

    setprice(event) {
        this.setState({ price: event.target.value })
    }

    sendData() {
        let reactData = { 'bookid': this.state.bookid, 'bookName': this.state.bookName, 'authorName': this.state.authorName, 'publishedDate': this.state.publishedDate, 'price': this.state.price };
        axios.post("http://localhost:3005/addBook", reactData)
            .then(res => alert('added successfully'))
            .catch(err => console.log(err.data))

    }

    checkPrice() {
        if (isNaN(this.state.price)) {
            this.setState({
                errormsgprice: 'this is not a number'
            })
        }
        else {
            this.setState({
                errormsgprice: ''
            })
        }
    }

    checkId() {
        if (isNaN(this.state.bookid)) {
            this.setState({
                errormsgid: 'this is not a number'
            })
        }
        else {
            this.setState({
                errormsgid: ''
            })
        }
    }

    render() {
        return (
            <div className="cdiv">
                <form className='cform'>
                <label>Book Id : </label>
                <input type='text' value={this.state.bookid} onChange={(e) => this.setbookid(e)}
                        onBlur={() => this.checkId()}></input>
                    <span style={{ color: 'red' }}>{this.state.errormsgid}</span><br />
                    <label>Book Name : </label>
                    <input type='text' value={this.state.bookName} onChange={(e) => this.setbookName(e)}></input><br />
                    <label>Author Name : </label>
                    <input type='text' value={this.state.authorName} onChange={(e) => this.setauthorName(e)}
                     ></input><br />
                     <label>Book Price : </label>
                    <input type='text' value={this.state.price} onChange={(e) => this.setprice(e)}
                        onBlur={() => this.checkPrice()}></input>
                    <span style={{ color: 'red' }}>{this.state.errormsgprice}</span><br />
                    <label>Published Date : </label>
                    <input type='Date' value={this.state.publishedDate} onChange={(e) => this.setpublishedDate(e)}></input><br />

                    <button type='submit' onClick={() => this.sendData()}>Submit</button>
                </form>
                
            </div>
        )
    }
}

export default AddBook;