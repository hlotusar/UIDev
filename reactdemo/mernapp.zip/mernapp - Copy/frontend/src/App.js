import logo from './logo.jpg';
import './App.css';
import Navbar from './Navbar';

function App() {
  return (
    <div className="App" >
      <div className='title'>
        <h1 id='head'>Library Management System</h1>
        <img id='logo' src={logo} height={100} width={100} />
      </div>
      <Navbar/>
      <footer className='footer'>&copy;copyright protected</footer>
    </div>
  );
}

export default App;


