import React, { Component } from 'react';
import axios from 'axios';

class ViewBooks extends Component {
    constructor() {
        super();
        this.state = {
            books: []
        }
        axios.get("http://localhost:3005/getBooks")
            .then((response) => {
                this.setState({
                    books: response.data
                })
                console.log('books')
                console.log(this.state.books)
            })
            .catch((err) => {
                console.log('Something went wrong')
            })
    }
    render() {
        let newLayout=this.state.books.map((book)=>
        <tr>
            <td>{book.bookid}</td>
            <td>{book.bookName}</td>
            <td>{book.authorName}</td>
            <td>{book.publishedDate}</td>
            <td>{book.price}</td>
        </tr>
      )
        return (
            <div>
                <h2>Book Details</h2>
                <table border='3'>
                    <tr>
                        <th>BookId</th><th>Book Name</th><th>Author Name</th><th>Published Date</th><th>Price</th>
                    </tr>
                    {newLayout}
                </table>
            </div>
        )
    }
}

export default ViewBooks;