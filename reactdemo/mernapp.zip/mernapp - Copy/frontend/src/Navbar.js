import React,{Component} from 'react';
import {Link} from 'react-router-dom';



class Navbar extends Component{
    render(){
        return(
            <div style={{height:'45px',fontSize:'20px' ,backgroundColor:'lightgreen'}}>
                <nav>
                    <Link id='lnk' to='/Home'>Home</Link>  
                    <Link id='lnk' to='/ViewBooks'> View Books</Link>
                    <Link id='lnk' to='/AddBook'> Add New Book</Link>
                    <Link id='lnk' to='/Contact'>Contact</Link>
                </nav>

                
            </div>
        )
    }
}

export default Navbar;