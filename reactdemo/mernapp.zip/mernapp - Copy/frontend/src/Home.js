import React,{Component} from 'react';


class Home extends Component{
    render(){
        return(
            <div>
                <h2>Welcome</h2><br></br>
                <h4>Library Management System</h4>
            </div>
        )
    }
}

export default Home;