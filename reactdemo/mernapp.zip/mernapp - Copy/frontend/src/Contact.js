import React, { Component } from 'react';
import './App.css';

class Contact extends Component {
    render() {
        return (
            <div>
                <h2>Contact Details</h2>
                <div id='contact'>
                    <h4>Library Management System</h4>
                    <p>
                        Phone : 12345678 <br/>
                        email : xyz@gmail.com
                    </p>
                </div>
            </div>
        )
    }
}

export default Contact;